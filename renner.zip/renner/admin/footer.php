
	<footer>
		<div class="container">
			<p>Versão 1.0</p>
			<p>MAFIA TECHNOLLOGY © Copyright <?php echo date('Y'); ?></p>
		</div>
	</footer>
